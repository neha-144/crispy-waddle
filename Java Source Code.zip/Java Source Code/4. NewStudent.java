package Admin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class NewStudent extends JFrame {

	private JPanel contentPane;
	private JTextField textName;
	private JTextField textStudent_id;
	private JTextField textPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewStudent frame = new NewStudent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewStudent() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ashmina Dangat\\Videos\\Captures\\A. P. Shah Institute of Technology, Thane - APSIT - \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920 _ Facebook - Google Chrome 13-10-2021 00_19_37.png"));
		setTitle("Admin Home");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1550, 830);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel.setBounds(318, 0, 127, 139);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
		lblNewLabel_1.setBounds(577, 10, 462, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 28));
		lblNewLabel_2.setBounds(474, 48, 652, 27);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\"We build dreams.\"");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_3.setBounds(670, 85, 257, 27);
		contentPane.add(lblNewLabel_3);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(28, 224, 1483, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(28, 149, 1483, 2);
		contentPane.add(separator_1);
		
		JLabel lblNewLabel_4 = new JLabel("Course name:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4.setBounds(272, 322, 139, 27);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Branch name:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_5.setBounds(272, 389, 139, 22);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Name:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_6.setBounds(272, 511, 139, 22);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Division:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_7.setBounds(272, 452, 139, 22);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Student Id:");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_8.setBounds(833, 324, 147, 22);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Gender:");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_9.setBounds(833, 389, 106, 22);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Password:");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_10.setForeground(new Color(0, 0, 0));
		lblNewLabel_10.setBounds(833, 452, 106, 22);
		contentPane.add(lblNewLabel_10);
		
		JButton btnNewButton_5 = new JButton("BACK");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new AdminHome().setVisible(true);
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_5.setBounds(765, 648, 128, 31);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_1_1 = new JButton("Add New Result");
		btnNewButton_1_1.setBounds(387, 172, 195, 31);
		contentPane.add(btnNewButton_1_1);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewResult().setVisible(true);
			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_1 = new JButton("Add New Student");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewStudent().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(145, 172, 195, 31);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.setForeground(Color.BLUE);
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_4 = new JButton("Logout");
		btnNewButton_4.setBounds(1126, 172, 195, 31);
		contentPane.add(btnNewButton_4);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFrame frmHomepage = new JFrame("Logout")	;	
					if(JOptionPane.showConfirmDialog(frmHomepage,"Do you want to log out?","Login error",JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
						Homepage info = new Homepage();
						Homepage.main(null);
					}
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_3 = new JButton("All Student Result");
		btnNewButton_3.setBounds(877, 172, 195, 31);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new CombinedResults().setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_2 = new JButton("Registered Students");
		btnNewButton_2.setBounds(628, 172, 195, 31);
		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new RegisteredStudents().setVisible(true);			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JLabel lblNewLabel_11 = new JLabel("New Student");
		lblNewLabel_11.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 23));
		lblNewLabel_11.setBounds(680, 240, 195, 27);
		contentPane.add(lblNewLabel_11);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setForeground(Color.BLACK);
		separator_2.setBounds(746, 289, 2, 277);
		contentPane.add(separator_2);
		
		final JComboBox comboCourse = new JComboBox();
		comboCourse.setBackground(Color.WHITE);
		comboCourse.setBounds(477, 328, 166, 21);
		comboCourse.addItem("B.Tech");
		comboCourse.setSelectedItem(null);
		contentPane.add(comboCourse);
		
		final JComboBox comboBranch = new JComboBox();
		comboBranch.setBackground(Color.WHITE);
		comboBranch.setBounds(477, 393, 166, 21);
		comboBranch.addItem("I.T");
		comboBranch.addItem("C.S");
		comboBranch.addItem("EXTC");
		comboBranch.addItem("Mechanical");
		comboBranch.addItem("Civil");
		comboBranch.setSelectedItem(null);
		contentPane.add(comboBranch);
		
		final JComboBox comboDiv = new JComboBox();
		comboDiv.setBackground(Color.WHITE);
		comboDiv.setBounds(477, 456, 166, 21);
		comboDiv.addItem("A");
		comboDiv.addItem("B");
		comboDiv.setSelectedItem(null);
		contentPane.add(comboDiv);
		
		textName = new JTextField();
		textName.setBounds(477, 516, 166, 19);
		contentPane.add(textName);
		textName.setColumns(10);
		
		textStudent_id = new JTextField();
		textStudent_id.setBounds(1009, 329, 166, 19);
		contentPane.add(textStudent_id);
		textStudent_id.setColumns(10);
		
		final JComboBox comboGender = new JComboBox();
		comboGender.setBackground(Color.WHITE);
		comboGender.setBounds(1009, 393, 166, 21);
		comboGender.addItem("Male");
		comboGender.addItem("Female");
		comboGender.setSelectedItem(null);
		contentPane.add(comboGender);
		
		textPassword = new JTextField();
		textPassword.setBounds(1009, 457, 166, 19);
		contentPane.add(textPassword);
		textPassword.setColumns(10);
		
		JButton btnNewButton = new JButton("CREATE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String CourseName = (String)comboCourse.getSelectedItem();
				String BranchName = (String)comboBranch.getSelectedItem();
				String Division = (String)comboDiv.getSelectedItem();
				String Name = textName.getText();
				String Student_id = textStudent_id.getText();
				String Gender = (String)comboGender.getSelectedItem();
				String Password = textPassword.getText();
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
					Statement st=con.createStatement();
					st.executeUpdate("insert into NewStudent(CourseName,BranchName,Name,Division,Student_id,Gender,Password) values('"+CourseName+"','"+BranchName+"','"+Name+"','"+Division+"','"+Student_id+"','"+Gender+"',md5('"+Password+"'))");
					JOptionPane.showMessageDialog(null,"Successfully Created");
					setVisible(false);
					new NewStudent().setVisible(true);
					st.close();
				}
				catch(Exception evt)
				{
					JOptionPane.showMessageDialog(null,"This roll number already exists");
					setVisible(false);
					new NewStudent().setVisible(true);
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 19));
		btnNewButton.setBounds(591, 648, 127, 31);
		contentPane.add(btnNewButton);
	}

}
