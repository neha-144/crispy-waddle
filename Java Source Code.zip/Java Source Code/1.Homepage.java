package Admin;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import org.eclipse.wb.swing.FocusTraversalOnArray;
import javax.swing.SwingConstants;

public class Homepage {

	private JFrame frmHomePage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Homepage window = new Homepage();
					window.frmHomePage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Homepage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmHomePage = new JFrame();
		frmHomePage.setForeground(new Color(128, 128, 128));
		frmHomePage.setFont(null);
		frmHomePage.setBackground(Color.WHITE);
		frmHomePage.setTitle("Home Page");
		frmHomePage.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ashmina Dangat\\Videos\\Captures\\A. P. Shah Institute of Technology, Thane - APSIT - \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920 _ Facebook - Google Chrome 13-10-2021 00_19_37.png"));
		frmHomePage.getContentPane().setBackground(Color.WHITE);
		frmHomePage.setBounds(0, 0, 1550, 830);
		frmHomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmHomePage.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("ADMIN LOGIN");
		btnNewButton.setBackground(SystemColor.menu);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new AdminLogin().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(1055, 117, 192, 42);
		frmHomePage.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("STUDENT LOGIN");
		btnNewButton_1.setBackground(SystemColor.menu);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentLogin StudentLogin = new StudentLogin();
				StudentLogin.main(null);
				
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(1276, 117, 209, 42);
		frmHomePage.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 28));
		lblNewLabel.setBackground(new Color(128, 128, 128));
		lblNewLabel.setBounds(526, 35, 649, 42);
		frmHomePage.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel_1.setBounds(372, -15, 129, 159);
		frmHomePage.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 22));
		lblNewLabel_2.setBounds(626, 10, 386, 24);
		frmHomePage.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("We build dreams.");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_3.setBounds(733, 78, 279, 24);
		frmHomePage.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Courses");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_4.setBounds(10, 203, 181, 24);
		frmHomePage.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Computer Engineering");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_5.setBounds(2, 231, 200, 24);
		frmHomePage.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Information Technology");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_6.setBounds(10, 253, 192, 24);
		frmHomePage.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Mechanical Engineering");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_7.setBounds(10, 276, 192, 24);
		frmHomePage.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Electrical Engineering");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_8.setBounds(10, 302, 192, 21);
		frmHomePage.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Civil Engineering");
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_9.setBounds(10, 324, 192, 24);
		frmHomePage.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Data Science (CSE)");
		lblNewLabel_10.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_10.setBounds(10, 349, 192, 24);
		frmHomePage.getContentPane().add(lblNewLabel_10);
		
		JButton btnNewButton_2 = new JButton("Home");
		btnNewButton_2.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_2.setBounds(10, 153, 96, 25);
		frmHomePage.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Admission");
		btnNewButton_3.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_3.setBounds(105, 153, 103, 25);
		frmHomePage.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Academics");
		btnNewButton_4.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_4.setBounds(201, 153, 112, 25);
		frmHomePage.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Skills");
		btnNewButton_5.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_5.setBounds(305, 153, 96, 25);
		frmHomePage.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Facalities");
		btnNewButton_6.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_6.setBounds(400, 153, 101, 25);
		frmHomePage.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Placement");
		btnNewButton_7.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_7.setBounds(499, 153, 103, 25);
		frmHomePage.getContentPane().add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("Institute");
		btnNewButton_8.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_8.setBounds(599, 153, 96, 25);
		frmHomePage.getContentPane().add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Pay Fees");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_9.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_9.setBounds(688, 153, 96, 25);
		frmHomePage.getContentPane().add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("Contact Us");
		btnNewButton_10.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_10.setBounds(777, 153, 112, 25);
		frmHomePage.getContentPane().add(btnNewButton_10);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Latest News", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(64, 64, 64)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(10, 398, 191, 183);
		frmHomePage.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_11 = new JLabel("New label");
		lblNewLabel_11.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\computer.jpg"));
		lblNewLabel_11.setBounds(256, 215, 318, 198);
		frmHomePage.getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Computer Science Engineering");
		lblNewLabel_12.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_12.setBounds(305, 398, 263, 24);
		frmHomePage.getContentPane().add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("New label");
		lblNewLabel_13.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\IT.jpg"));
		lblNewLabel_13.setBounds(610, 231, 307, 167);
		frmHomePage.getContentPane().add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("IT Engineering");
		lblNewLabel_14.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_14.setBounds(707, 398, 161, 24);
		frmHomePage.getContentPane().add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("New label");
		lblNewLabel_15.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\mechanical.jpg"));
		lblNewLabel_15.setBounds(954, 231, 279, 167);
		frmHomePage.getContentPane().add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("Mechanical Engineering");
		lblNewLabel_16.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_16.setBounds(1006, 402, 186, 20);
		frmHomePage.getContentPane().add(lblNewLabel_16);
		
		JLabel lblNewLabel_17 = new JLabel("New label");
		lblNewLabel_17.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\civil.jpg"));
		lblNewLabel_17.setBounds(407, 450, 318, 163);
		frmHomePage.getContentPane().add(lblNewLabel_17);
		
		JLabel lblNewLabel_18 = new JLabel("Civil Engineering");
		lblNewLabel_18.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_18.setBounds(499, 612, 192, 24);
		frmHomePage.getContentPane().add(lblNewLabel_18);
		
		JLabel lblNewLabel_19 = new JLabel("New label");
		lblNewLabel_19.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\data science.jpeg"));
		lblNewLabel_19.setBounds(765, 450, 293, 163);
		frmHomePage.getContentPane().add(lblNewLabel_19);
		
		JLabel lblNewLabel_20 = new JLabel("Data Science Engineering");
		lblNewLabel_20.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_20.setBounds(830, 612, 192, 24);
		frmHomePage.getContentPane().add(lblNewLabel_20);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Notifications", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(10, 591, 191, 183);
		frmHomePage.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_21 = new JLabel("Scholarship");
		lblNewLabel_21.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_21.setBounds(10, 21, 137, 18);
		panel_1.add(lblNewLabel_21);
		
		JLabel lblNewLabel_22 = new JLabel("Admission Notifications");
		lblNewLabel_22.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_22.setBounds(10, 47, 156, 13);
		panel_1.add(lblNewLabel_22);
		
		JLabel lblNewLabel_23 = new JLabel("University Exams 2021-22");
		lblNewLabel_23.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_23.setBounds(10, 70, 171, 13);
		panel_1.add(lblNewLabel_23);
		
		JLabel lblNewLabel_24 = new JLabel("College Brochure");
		lblNewLabel_24.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_24.setBounds(10, 87, 156, 18);
		panel_1.add(lblNewLabel_24);
		
		JLabel lblNewLabel_25 = new JLabel("NAAC");
		lblNewLabel_25.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_25.setBounds(10, 115, 45, 13);
		panel_1.add(lblNewLabel_25);
		
		JLabel lblNewLabel_26 = new JLabel("College Commitees");
		lblNewLabel_26.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_26.setBounds(10, 134, 156, 18);
		panel_1.add(lblNewLabel_26);
		
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(new Color(0, 0, 0));
		panel_2.setBackground(Color.WHITE);
		panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Useful Links", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_2.setBounds(1276, 203, 237, 378);
		frmHomePage.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "Contact Info", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLACK));
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(1276, 591, 237, 183);
		frmHomePage.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_27 = new JLabel("Opp. Hypercity Mall, Kasarvadavali,");
		lblNewLabel_27.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_27.setBounds(10, 41, 217, 13);
		panel_3.add(lblNewLabel_27);
		
		JLabel lblNewLabel_28 = new JLabel("Ghodbunder Road, Thane West,");
		lblNewLabel_28.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_28.setBounds(10, 60, 201, 13);
		panel_3.add(lblNewLabel_28);
		
		JLabel lblNewLabel_29 = new JLabel("Thane, Maharashtra 400615");
		lblNewLabel_29.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_29.setBounds(10, 77, 201, 13);
		panel_3.add(lblNewLabel_29);
		
		JLabel lblNewLabel_30 = new JLabel("Address: Survey No. 12, 13");
		lblNewLabel_30.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_30.setBounds(10, 18, 201, 21);
		panel_3.add(lblNewLabel_30);
		
		JLabel lblNewLabel_31 = new JLabel("Phone: 022-25973737");
		lblNewLabel_31.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_31.setBounds(10, 110, 201, 21);
		panel_3.add(lblNewLabel_31);
		
		JLabel lblNewLabel_32 = new JLabel("Mobile: 7738305400 / 7738940600");
		lblNewLabel_32.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_32.setBounds(10, 149, 201, 13);
		panel_3.add(lblNewLabel_32);
		
		JLabel lblNewLabel_33 = new JLabel("Institute Vision");
		lblNewLabel_33.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblNewLabel_33.setBounds(232, 644, 192, 24);
		frmHomePage.getContentPane().add(lblNewLabel_33);
		
		JTextArea txtrApsitAspiresTo = new JTextArea();
		txtrApsitAspiresTo.setFont(new Font("Monospaced", Font.BOLD, 17));
		txtrApsitAspiresTo.setText("APSIT aspires to be a premier institute producing globally competent engineering professionals to contribute towards socio-economic growth of India.");
		txtrApsitAspiresTo.setBounds(232, 679, 984, 30);
		frmHomePage.getContentPane().add(txtrApsitAspiresTo);
		
		JTextArea txtrContributeTowardsSocioeconomic = new JTextArea();
		txtrContributeTowardsSocioeconomic.setFont(new Font("Monospaced", Font.BOLD, 17));
		txtrContributeTowardsSocioeconomic.setText("contribute towards socio-economic growth of India.");
		txtrContributeTowardsSocioeconomic.setBounds(230, 708, 589, 22);
		frmHomePage.getContentPane().add(txtrContributeTowardsSocioeconomic);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setForeground(Color.BLACK);
		separator_2.setBounds(211, 218, 2, 556);
		frmHomePage.getContentPane().add(separator_2);
		
		JSeparator separator_2_1 = new JSeparator();
		separator_2_1.setOrientation(SwingConstants.VERTICAL);
		separator_2_1.setForeground(Color.BLACK);
		separator_2_1.setBounds(1264, 203, 2, 571);
		frmHomePage.getContentPane().add(separator_2_1);
		frmHomePage.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{frmHomePage.getContentPane(), btnNewButton, btnNewButton_1, lblNewLabel, lblNewLabel_1, lblNewLabel_2}));
	}

	protected void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
