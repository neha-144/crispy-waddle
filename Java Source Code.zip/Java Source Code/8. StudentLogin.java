package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;
import java.util.Vector;
import org.eclipse.wb.swing.FocusTraversalOnArray;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.security.auth.callback.PasswordCallback;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Component;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFormattedTextField;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.*;

import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

public class StudentLogin {

	private JFrame frmStudentLogin;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentLogin window = new StudentLogin();
					window.frmStudentLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmStudentLogin = new JFrame();
		frmStudentLogin.setTitle("Student Login");
		frmStudentLogin.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ashmina Dangat\\Videos\\Captures\\A. P. Shah Institute of Technology, Thane - APSIT - \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920 _ Facebook - Google Chrome 13-10-2021 00_19_37.png"));
		frmStudentLogin.getContentPane().setBackground(Color.WHITE);
		frmStudentLogin.setBounds(0, 0, 1550, 830);
		frmStudentLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmStudentLogin.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel.setBounds(318, 0, 127, 139);
		frmStudentLogin.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
		lblNewLabel_1.setBounds(577, 10, 462, 27);
		frmStudentLogin.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 28));
		lblNewLabel_2.setBounds(474, 48, 652, 27);
		frmStudentLogin.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\"We build dreams.\"");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_3.setBounds(670, 85, 257, 27);
		frmStudentLogin.getContentPane().add(lblNewLabel_3);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.BLACK, 4, true));
		panel.setBackground(Color.WHITE);
		panel.setBounds(497, 185, 499, 486);
		frmStudentLogin.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Student Login");
		lblNewLabel_4.setBounds(162, 46, 197, 42);
		panel.add(lblNewLabel_4);
		lblNewLabel_4.setBackground(Color.BLACK);
		lblNewLabel_4.setForeground(Color.BLACK);
		lblNewLabel_4.setFont(new Font("Yu Gothic", Font.BOLD, 28));
		
		JLabel lblNewLabel_5 = new JLabel("Username :");
		lblNewLabel_5.setBounds(123, 157, 116, 27);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setForeground(Color.BLACK);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textField.setBounds(271, 160, 116, 27);
		panel.add(textField);
		textField.setColumns(10);
		
		
		JLabel lblNewLabel_6 = new JLabel("Password :");
		lblNewLabel_6.setBounds(123, 235, 129, 27);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setForeground(Color.BLACK);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		passwordField.setBounds(271, 235, 116, 27);
		panel.add(passwordField);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Student_id = textField.getText();
			String Password = passwordField.getText();	
			
			try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
					Statement st = con.createStatement();
					String query = "select *from NewStudent JOIN NewResult_sem1 using (Student_id) where Student_id='"+Student_id+"' and Password=md5('"+Password+"')";
					ResultSet rs = st.executeQuery(query);
					
					
					
					
					if(rs.next())
					{
						setVisible(false);
				new StudentPage(Student_id).setVisible(true);
					
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Invalid Username or password");	
					}
					
				}
				catch(Exception evt)
				{
					JOptionPane.showMessageDialog(null,"Connection error");
			}
			}
		});  
					
			
		btnNewButton.setBounds(119, 400, 120, 42);
		panel.add(btnNewButton);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 21));
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(66, 111, 362, 2);
		panel.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(66, 309, 362, 2);
		panel.add(separator_1);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(259, 400, 120, 42);
		panel.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Homepage info = new Homepage();
				Homepage.main(null);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 21));
		
		JButton btnNewButton_2 = new JButton("Change Password ");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Student_id = textField.getText();
				setVisible(false);
				new PasswordChange().setVisible(true);
			}
		});
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(150, 321, 197, 27);
		panel.add(btnNewButton_2);
		
		
		
		
		
		
		
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
