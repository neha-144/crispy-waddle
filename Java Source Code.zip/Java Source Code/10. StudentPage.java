package Admin;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

public class StudentPage extends JFrame {

	private JPanel contentPane;
	private JTextField textName;
	private JTextField textStudent_id;
	private JTextField textDivision;
	private JTextField textCourse;
	private JTextField textBranch;
	private JTextField textGender;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentPage frame = new StudentPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public StudentPage(String Student_id) {
		initComponents();
		textStudent_id.setText(Student_id);
			
		
	}
	

	/**
	 * Create the frame.
	 * @return 
	 */
	public  StudentPage(){
		initComponents();
	}
	
	
	
	
	
		

	/**
	 * Create the frame.
	 */
	private void initComponents() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ashmina Dangat\\Videos\\Captures\\A. P. Shah Institute of Technology, Thane - APSIT - \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920 _ Facebook - Google Chrome 13-10-2021 00_19_37.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1550, 830);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel.setBounds(337, 0, 127, 139);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
		lblNewLabel_2.setBounds(611, 0, 462, 27);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_5 = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 28));
		lblNewLabel_5.setBounds(508, 31, 652, 27);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\"We build dreams.\"");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_6.setBounds(699, 68, 257, 27);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_1 = new JLabel("User Details :");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 26));
		lblNewLabel_1.setBounds(275, 166, 147, 27);
		contentPane.add(lblNewLabel_1);
		
		textName = new JTextField();
		textName.setBackground(Color.WHITE);
		textName.setEditable(false);
		textName.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textName.setBounds(441, 227, 202, 27);
		contentPane.add(textName);
		textName.setColumns(10);
		
		textStudent_id = new JTextField();
		textStudent_id.setBackground(Color.WHITE);
		textStudent_id.setEditable(false);
		textStudent_id.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textStudent_id.setBounds(441, 286, 202, 27);
		contentPane.add(textStudent_id);
		textStudent_id.setColumns(10);
		
		textDivision = new JTextField();
		textDivision.setEditable(false);
		textDivision.setBackground(new Color(255, 255, 255));
		textDivision.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textDivision.setBounds(441, 343, 202, 25);
		contentPane.add(textDivision);
		textDivision.setColumns(10);
		
		textCourse = new JTextField();
		textCourse.setEditable(false);
		textCourse.setBackground(Color.WHITE);
		textCourse.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textCourse.setBounds(1017, 227, 202, 27);
		contentPane.add(textCourse);
		textCourse.setColumns(10);
		
		textBranch = new JTextField();
		textBranch.setBackground(Color.WHITE);
		textBranch.setEditable(false);
		textBranch.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textBranch.setBounds(1017, 286, 202, 27);
		contentPane.add(textBranch);
		textBranch.setColumns(10);
		
		textGender = new JTextField();
		textGender.setEditable(false);
		textGender.setBackground(Color.WHITE);
		textGender.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textGender.setBounds(1017, 342, 202, 27);
		contentPane.add(textGender);
		textGender.setColumns(10);
		
		JLabel labelName = new JLabel("Name :");
		labelName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		labelName.setBounds(272, 232, 96, 13);
		contentPane.add(labelName);
		
		JLabel labelStudent_id = new JLabel("Student_id :");
		labelStudent_id.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		labelStudent_id.setBounds(275, 284, 111, 27);
		contentPane.add(labelStudent_id);
		
		JLabel labelDiv = new JLabel("Division :");
		labelDiv.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		labelDiv.setBounds(272, 340, 111, 27);
		contentPane.add(labelDiv);
		
		JLabel labelCourse = new JLabel("Course Name :");
		labelCourse.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		labelCourse.setBounds(798, 229, 139, 19);
		contentPane.add(labelCourse);
		
		JLabel labelBranch = new JLabel("Branch Name :");
		labelBranch.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		labelBranch.setBounds(798, 284, 139, 26);
		contentPane.add(labelBranch);
		
		JLabel lblNewLabel_3 = new JLabel("Gender :");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(798, 344, 111, 19);
		contentPane.add(lblNewLabel_3);
		
		JLabel labelProgress = new JLabel("Progress :");
		labelProgress.setFont(new Font("Times New Roman", Font.PLAIN, 26));
		labelProgress.setBounds(275, 416, 147, 27);
		contentPane.add(labelProgress);
		
		JButton btnNewButton = new JButton("View Result :");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Student_id = textStudent_id.getText();
				setVisible(false);
				new Studenthome(Student_id).setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(455, 419, 144, 27);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("View ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String Student_id = textStudent_id.getText();
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
					Statement st = con.createStatement();
					String query = "select *from NewStudent where Student_id='"+Student_id+"'" ;
					ResultSet rs = st.executeQuery(query);
					if(rs.next()) {
					textName.setText(rs.getString(3));
					textDivision.setText(rs.getString(4));
					textCourse.setText(rs.getString(1));
					textBranch.setText(rs.getString(2));
					textGender.setText(rs.getString(6));
					}
				}
					catch(Exception e1) 
				{
						JOptionPane.showMessageDialog(null,"Connection error");
				}
		    }	
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton_1.setBounds(469, 168, 85, 27);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(371, 497, 973, 41);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"Physics", "Chemistry", "Mathematics", "Mechanics", "Basic Electrical Engineering", "Total ", "Percentage"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_2 = new JButton("Sem 1");
		btnNewButton_2.setForeground(new Color(0, 0, 0));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Student_id = textStudent_id.getText();
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select Physics, Chemistry, Mathematics, Mechanics, BasicElectricalEngineering, Total, Percentage from NewResult_sem1  where Student_id = '"+Student_id+"' ");
					table.setModel( net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
		            
				}
				catch(Exception evt)
				{
					JOptionPane.showMessageDialog(null,"Connection Error");
					
				}
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_2.setBounds(247, 495, 85, 27);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Sem 2");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Student_id = textStudent_id.getText();
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select Physics, Chemistry, Mathematics, Mechanics, BasicElectricalEngineering, Total, Percentage from NewResult_sem2  where Student_id = '"+Student_id+"' ");
					table_1.setModel( net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
		            
				}
				catch(Exception evt)
				{
					JOptionPane.showMessageDialog(null,"Connection Error");
					
				}
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnNewButton_3.setBounds(247, 585, 85, 27);
		contentPane.add(btnNewButton_3);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setToolTipText("");
		scrollPane_1.setBounds(371, 583, 970, 41);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"Physics", "Chemistry", "Mathematics", "Mechanics", "Basic Electrical Engineering", "Total", "Percentage"
			}
		));
		scrollPane_1.setViewportView(table_1);
		
		JButton btnNewButton_4 = new JButton("Logout ");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frmHomepage = new JFrame("Logout")	;	
				if(JOptionPane.showConfirmDialog(frmHomepage,"Do you want to log out?","Login error",JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					Homepage info = new Homepage();
					Homepage.main(null);
				}
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNewButton_4.setBounds(1430, 10, 96, 34);
		contentPane.add(btnNewButton_4);
		
	}
}
