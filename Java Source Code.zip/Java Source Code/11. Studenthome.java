package Admin;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.print.*;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class Studenthome extends JFrame {

	private JPanel contentPane;
	private JPanel panel;
	private JTextField textcourse;
	private JTextField textbranch;
	private JTextField textname;
	private JTextField textdiv;
	private  JTextField textStudent_id;
	private JTextField textGender;
	private JTextField textphysics;
	private JTextField textChemistry;
	private JTextField textMaths;
	private JTextField textMech;
	private JTextField textBEE;
	private JTextField textTotal;
	private JTextField textPercent;
	private JTextField textField_13;
	private JTextField textField;
	private JPasswordField passwordField;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Studenthome frame = new Studenthome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Studenthome(String Student_id) {
		initComponents();
		textStudent_id.setText(Student_id);
			
		
	}
	

	/**
	 * Create the frame.
	 */
	public Studenthome(){
		initComponents();
	}
	
	
	
	
	
		private void initComponents() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ashmina Dangat\\Videos\\Captures\\A. P. Shah Institute of Technology, Thane - APSIT - \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920 _ Facebook - Google Chrome 13-10-2021 00_19_37.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1550, 830);
		contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel.setBounds(318, 0, 127, 139);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
		lblNewLabel_2.setBounds(577, 10, 462, 27);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_5 = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 28));
		lblNewLabel_5.setBounds(474, 48, 652, 27);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\"We build dreams.\"");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_6.setBounds(670, 85, 257, 27);
		contentPane.add(lblNewLabel_6);
		
		final JPanel panel = new JPanel();
		panel.setBounds(318, 146, 900, 567);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Course Name :");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(34, 20, 124, 21);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Branch Name :");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(34, 65, 124, 21);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Name :");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_4.setBounds(34, 110, 114, 21);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_7 = new JLabel("Division :");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_7.setBounds(509, 20, 124, 21);
		panel.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Student_id :");
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_8.setBounds(509, 65, 124, 21);
		panel.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Gender :");
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_9.setBounds(509, 110, 124, 21);
		panel.add(lblNewLabel_9);
		
		textcourse = new JTextField();
		textcourse.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textcourse.setBackground(Color.WHITE);
		textcourse.setEditable(false);
		textcourse.setBounds(196, 23, 204, 19);
		panel.add(textcourse);
		textcourse.setColumns(10);
		
		textbranch = new JTextField();
		textbranch.setBackground(Color.WHITE);
		textbranch.setEditable(false);
		textbranch.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textbranch.setBounds(196, 68, 204, 19);
		panel.add(textbranch);
		textbranch.setColumns(10);
		
		textname = new JTextField();
		textname.setEditable(false);
		textname.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textname.setBackground(Color.WHITE);
		textname.setBounds(196, 113, 204, 19);
		panel.add(textname);
		textname.setColumns(10);
		
		textdiv = new JTextField();
		textdiv.setEditable(false);
		textdiv.setBackground(Color.WHITE);
		textdiv.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textdiv.setBounds(643, 23, 204, 19);
		panel.add(textdiv);
		textdiv.setColumns(10);
		
		textStudent_id = new JTextField();
		textStudent_id.setEditable(false);
		textStudent_id.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textStudent_id.setBackground(Color.WHITE);
		textStudent_id.setBounds(643, 68, 204, 19);
		panel.add(textStudent_id);
		textStudent_id.setColumns(10);
		
		textGender = new JTextField();
		textGender.setBackground(Color.WHITE);
		textGender.setEditable(false);
		textGender.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textGender.setBounds(643, 113, 204, 19);
		panel.add(textGender);
		textGender.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(-396, 152, 1483, 2);
		panel.add(separator);
		
		JLabel lblNewLabel_10 = new JLabel("Physics :");
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_10.setBounds(34, 226, 186, 21);
		panel.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Chemistry :");
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_11.setBounds(34, 257, 204, 21);
		panel.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Mathematics :");
		lblNewLabel_12.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_12.setBounds(34, 310, 204, 21);
		panel.add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("Mechanics :");
		lblNewLabel_13.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_13.setBounds(34, 363, 204, 21);
		panel.add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("Basic Electrical Engineering :");
		lblNewLabel_14.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_14.setBounds(34, 416, 224, 21);
		panel.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("Total :");
		lblNewLabel_15.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_15.setBounds(34, 467, 186, 21);
		panel.add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("Marks Obtained ");
		lblNewLabel_16.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_16.setBounds(375, 164, 156, 29);
		panel.add(lblNewLabel_16);
		
		JLabel lblNewLabel_17 = new JLabel("Total Marks ");
		lblNewLabel_17.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_17.setBounds(628, 164, 156, 29);
		panel.add(lblNewLabel_17);
		
		textphysics = new JTextField();
		textphysics.setHorizontalAlignment(SwingConstants.CENTER);
		textphysics.setBackground(Color.WHITE);
		textphysics.setEditable(false);
		textphysics.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		textphysics.setBounds(401, 203, 77, 30);
		panel.add(textphysics);
		textphysics.setColumns(10);
		
		textMaths = new JTextField();
		textMaths.setHorizontalAlignment(SwingConstants.CENTER);
		textMaths.setBackground(Color.WHITE);
		textMaths.setEditable(false);
		textMaths.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textMaths.setBounds(401, 310, 77, 28);
		panel.add(textMaths);
		textMaths.setColumns(10);
		
		textMech = new JTextField();
		textMech.setHorizontalAlignment(SwingConstants.CENTER);
		textMech.setBackground(Color.WHITE);
		textMech.setEditable(false);
		textMech.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		textMech.setBounds(401, 363, 77, 28);
		panel.add(textMech);
		textMech.setColumns(10);
		
		textBEE = new JTextField();
		textBEE.setHorizontalAlignment(SwingConstants.CENTER);
		textBEE.setEditable(false);
		textBEE.setBackground(Color.WHITE);
		textBEE.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		textBEE.setBounds(401, 416, 77, 28);
		panel.add(textBEE);
		textBEE.setColumns(10);
		
		textTotal = new JTextField();
		textTotal.setHorizontalAlignment(SwingConstants.CENTER);
		textTotal.setEditable(false);
		textTotal.setBackground(Color.WHITE);
		textTotal.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textTotal.setBounds(401, 467, 77, 28);
		panel.add(textTotal);
		textTotal.setColumns(10);
		
		JLabel lblNewLabel_18 = new JLabel("100");
		lblNewLabel_18.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_18.setBounds(638, 209, 45, 13);
		panel.add(lblNewLabel_18);
		
		JLabel lblNewLabel_19 = new JLabel("100");
		lblNewLabel_19.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_19.setBounds(638, 261, 45, 13);
		panel.add(lblNewLabel_19);
		
		JLabel lblNewLabel_20 = new JLabel("100");
		lblNewLabel_20.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_20.setBounds(638, 316, 45, 13);
		panel.add(lblNewLabel_20);
		
		JLabel lblNewLabel_21 = new JLabel("100");
		lblNewLabel_21.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_21.setBounds(638, 372, 45, 13);
		panel.add(lblNewLabel_21);
		
		JLabel lblNewLabel_22 = new JLabel("100");
		lblNewLabel_22.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_22.setBounds(638, 425, 45, 13);
		panel.add(lblNewLabel_22);
		
		JLabel lblNewLabel_23 = new JLabel("100");
		lblNewLabel_23.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_23.setBounds(638, 474, 45, 13);
		panel.add(lblNewLabel_23);
		
		JLabel lblNewLabel_24 = new JLabel("Percentage :");
		lblNewLabel_24.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_24.setBounds(34, 520, 124, 29);
		panel.add(lblNewLabel_24);
		
		textPercent = new JTextField();
		textPercent.setHorizontalAlignment(SwingConstants.CENTER);
		textPercent.setEditable(false);
		textPercent.setBackground(Color.WHITE);
		textPercent.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		textPercent.setBounds(225, 522, 96, 29);
		panel.add(textPercent);
		textPercent.setColumns(10);
		
		textChemistry = new JTextField();
		textChemistry.setBounds(401, 257, 77, 28);
		panel.add(textChemistry);
		textChemistry.setHorizontalAlignment(SwingConstants.CENTER);
		textChemistry.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		textChemistry.setEditable(false);
		textChemistry.setBackground(Color.WHITE);
		textChemistry.setColumns(10);
	
		
		JButton btnNewButton = new JButton("Download");
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				printRecord(contentPane);
			}
		});
		btnNewButton.setBounds(699, 737, 146, 27);
		contentPane.add(btnNewButton);
			
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(1305, 131, 132, 21);
		comboBox.addItem("Sem 1");
		comboBox.addItem("Sem 2");
		comboBox.setSelectedItem(null);
		contentPane.add(comboBox);
		
		JButton btnNewButton_2 = new JButton("Search");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Semester = (String)comboBox.getSelectedItem();
				String Student_id = textStudent_id.getText();
				if(Semester.contains("Sem 1")) {
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
						Statement st = con.createStatement();
						String query = "select *from NewStudent JOIN NewResult_sem1 using (Student_id) where Student_id='"+Student_id+"'" ;
						ResultSet rs = st.executeQuery(query);
						
						
						if(rs.next())
						{
						textbranch.setText(rs.getString(3));
						textcourse.setText(rs.getString(2));
						textname.setText(rs.getString(4));
						textdiv.setText(rs.getString(5));
						
						textGender.setText(rs.getString(6));
						textphysics.setText(rs.getString(8));
						textChemistry.setText(rs.getString(9));
						textMaths.setText(rs.getString(10));
						textMech.setText(rs.getString(11));
						textBEE.setText(rs.getString(12));
						textTotal.setText(rs.getString(13));
						textPercent.setText(rs.getString(14));
						}
						else
						{
							JOptionPane.showMessageDialog(null,"Invalid Username or password");	
						}
						
					}
					catch(Exception evt)
					{
						JOptionPane.showMessageDialog(null,"Connection error");
				}

					
				}
				else if(Semester.contains("Sem 2")) {
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
						Statement st = con.createStatement();
						String query = "select *from NewStudent JOIN NewResult_sem2 using (Student_id) where Student_id='"+Student_id+"'" ;
						ResultSet rs = st.executeQuery(query);
						
						
						if(rs.next())
						{
						textbranch.setText(rs.getString(3));
						textcourse.setText(rs.getString(2));
						textname.setText(rs.getString(4));
						textdiv.setText(rs.getString(5));
						
						textGender.setText(rs.getString(6));
						textphysics.setText(rs.getString(8));
						textChemistry.setText(rs.getString(9));
						textMaths.setText(rs.getString(10));
						textMech.setText(rs.getString(11));
						textBEE.setText(rs.getString(12));
						textTotal.setText(rs.getString(13));
						textPercent.setText(rs.getString(14));
						}
						else
						{
							JOptionPane.showMessageDialog(null,"Invalid Username or password");	
						}
						
					}
					catch(Exception evt)
					{
						JOptionPane.showMessageDialog(null,"Connection error");
				}

					
					
				}
			}
		});
		btnNewButton_2.setBounds(1291, 194, 146, 21);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new StudentPage().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNewButton_1.setBounds(10, 13, 85, 27);
		contentPane.add(btnNewButton_1);
		
		
		
		
		}
	
	

	private void printJPanel() {
		// TODO Auto-generated method stub
		
	}

	private void printComponent() {
		// TODO Auto-generated method stub
		
	}

	

	

	private void initialize() {
		// TODO Auto-generated method stub
	}	
		public void printRecord(final JPanel contentPane ) {
			PrinterJob printerJob = PrinterJob.getPrinterJob();
			printerJob.setJobName("Print Result");
			printerJob.setPrintable(new Printable() {
				public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) 
				throws PrinterException {
					if(pageIndex > 0) {
						return Printable.NO_SUCH_PAGE;
						
					}
					Graphics2D graphics2D = (Graphics2D)graphics;
					graphics2D.translate(pageFormat.getImageableX()*2, pageFormat.getImageableY()*2);
					graphics2D.scale(0.5, 0.5);
					contentPane.paint(graphics2D);
					return Printable.PAGE_EXISTS;
					}
	       });
			
			boolean returningResult = printerJob.printDialog()
;
			if(returningResult) {
				try {
					printerJob.print();
				}
				catch(PrinterException printerException) {
					JOptionPane.showMessageDialog(this, "Print Error: " + printerException.getMessage());
				}
				}
			}
}
